//
//  ViewController.swift
//  BackgroundTasks
//
//  Created by CoderSLZeng on 2019/1/28.
//  Copyright © 2019 CoderSLZeng. All rights reserved.
//

import UIKit
import AVFoundation
import MediaPlayer

let kLastCounter = "lastCounter"

class ViewController: UIViewController {

    /// Mark - Property
    @IBOutlet weak var audioBtn: UIButton!
    @IBOutlet weak var backgroundBtn: UIButton!
    var audioPlayer : AVAudioPlayer?
    
    // MARK: - Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupAudio()
    }
    
    override func remoteControlReceived(with event: UIEvent?) {
        guard let event = event else { return }
        if event.type != UIEvent.EventType.remoteControl { return }
        
        switch event.subtype {
        case .remoteControlTogglePlayPause:
            print("暂停/播放")
        case .remoteControlPreviousTrack:
            print("上一首")
        case .remoteControlNextTrack:
            print("下一首")
        case .remoteControlPlay:
            print("播放")
            audioPlayer?.play()
            setupNowPlayingInfo(1.0)
        case .remoteControlPause:
            print("暂停")
            audioPlayer?.pause()
            setupNowPlayingInfo(0)
        default:
            break
        }
    }
}

/// Mark - Action
extension ViewController {
    
    @IBAction func palyBackgroundMusicTouched(_ sender: UIButton) {
        
        guard let _ = self.audioPlayer else { return }
        
        if audioPlayer!.isPlaying {
            audioPlayer?.stop()
            sender.setTitle("播放后台音乐", for: .normal)
            return
        }
        
        setupNowPlayingInfo(1.0)
        
        audioPlayer?.play()
        sender.setTitle("停止后台音乐", for: .normal)
        becomeFirstResponder()
        UIApplication.shared.beginReceivingRemoteControlEvents()
    }
    
    
    @IBAction func startBackgroundTaskTouched(_ sender: UIButton) {
        
        let device = UIDevice.current
        
        // 判断当前设备是否支持处理多任务
        if !device.isMultitaskingSupported {
            print("当前是设备不支持处理多任务")
            return;
        }
        
        backgroundBtn.isEnabled = false
        let btnTitle = "正在运行后台任务"
        backgroundBtn.setTitle(btnTitle, for: .normal)
        
        DispatchQueue.global(qos: .default).async {
            self.performBackgroundTask()
        }
        
    }
}

// MARK: - Private methond
extension ViewController {
    
    /// 设置后台播放显示信息
    ///
    /// - Parameter playbackRate: 播放速率
    fileprivate func setupNowPlayingInfo(_ playbackRate: Double) {
        let mpic = MPNowPlayingInfoCenter.default()
        
        // 专辑封面
        let mySize = CGSize(width: 400, height: 400)
        let albumArt = MPMediaItemArtwork(boundsSize:mySize) { size in
            return UIImage(named: "book_cover")!
        }
        
        // 获取进度
        let postion: Double = Double(audioPlayer?.currentTime ?? 0)
        let duration: Double = Double(audioPlayer?.duration ?? 0)
        
        mpic.nowPlayingInfo = [MPMediaItemPropertyTitle: "我是歌曲标题",
                               MPMediaItemPropertyArtist: "github.com",
                               MPMediaItemPropertyArtwork: albumArt,
                               MPNowPlayingInfoPropertyElapsedPlaybackTime: postion,
                               MPMediaItemPropertyPlaybackDuration: duration,
                               MPNowPlayingInfoPropertyPlaybackRate: playbackRate]
    }
    
    fileprivate func setupAudio() {
        let audioSession = AVAudioSession.sharedInstance()
        try? audioSession.setActive(true, options: [])
        try? audioSession.setCategory(.playback,
                                      mode: .default,
                                      options: .allowAirPlay)
        
        guard let audioPath = Bundle.main.path(forResource: "background_audio", ofType: "mp3") else { return }
        let audioURL = URL(fileURLWithPath: audioPath)
        try? audioPlayer = AVAudioPlayer(contentsOf: audioURL)
    }
    
    fileprivate func performBackgroundTask() {
        
        // 1.初始化计数器
        let counter: Int = 0
        
        // 2.定义后台任务的标识符
        var bTask: UIBackgroundTaskIdentifier? = nil
        
        // 3.开始后台任务
        bTask = UIApplication.shared.beginBackgroundTask(expirationHandler: {
            print("已调用后台过期处理程序")
            
            if bTask == nil { return }
            print("计数器 = \(counter), 任务ID = \(bTask!)).")
            
            UIApplication.shared.endBackgroundTask(bTask!)
            bTask = .invalid
        })
        
        // 4.存储计数器
        let userDefaults = UserDefaults.standard
        let startCounter = userDefaults.integer(forKey: kLastCounter)
        
        // 5.设置时长
        let twentySeconds = 20
        
        print("正在运行后台任务，任务ID = \(bTask!)")
        
        // 6.执行任务的代码
        for counter in startCounter...twentySeconds {
            // 6.1.睡眠1秒
            Thread.sleep(forTimeInterval: 1)
            userDefaults.set(counter, forKey: kLastCounter)
            userDefaults.synchronize()
            
            // 获取剩余时间
            let remainingTime = Double(UIApplication.shared.backgroundTimeRemaining)
            
            if remainingTime == .greatestFiniteMagnitude {
                print("后台任务 = \(counter)，仍在前台")
            } else {
                print("后台任务 = \(counter)，剩余时间 = \(remainingTime)")
            }
        }
        
        print("后台任务已完成")
        
        userDefaults.set(0, forKey: kLastCounter)
        userDefaults.synchronize()
        
        DispatchQueue.main.sync {
            self.backgroundBtn.isEnabled = true
            self.backgroundBtn.setTitle("开始后台任务", for: .normal)
        }
        
        if bTask == nil { return }
        
        UIApplication.shared.endBackgroundTask(bTask!)
        bTask = .invalid
        
    }
}
